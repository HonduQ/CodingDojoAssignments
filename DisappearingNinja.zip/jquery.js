        $(function(){
            
        $("#allContent").hide()
        $("#snacksBack").hide()
        })
        
        $("#reveal").on("click", function(){
            $("#allContent").show()
            $(this).hide()
        })

        $("#snickers").on("click", function(){
            $(this).hide();
        })
        $("#kitkat").on("click", function(){
            $(this).hide();
        })
        $("#butterfingers").on("click", function(){
            $(this).hide();
        })
        $("#reeses").on("click", function(){
            $(this).hide();
        })
        $("#almondjoy").on("click", function(){
            $(this).hide();
        })
        $("#mounds").on("click", function(){
            $(this).hide();
        })
        $("#twix").on("click", function(){
            $(this).hide();
        })
        $("#chunky").on("click", function(){
            $(this).hide();
            console.log("yup");
        })

        $(".candybar").on("click", function(){
            $("#snacksBack").show()
        })

        $("#snacksBack").on("click", function(){
            $(".candybar").show()
        })